@extends('main')
@section('content')
<div class="content">
    <div class="container-fluid">
		<div class="row">
			<div class="col-lg-12 col-md-11">
				 <div class="card">
					<div class="header">
						<h4 class="title"><?php echo trans('lang.all_reports');?></h4>
						<hr>
					</div>
					<div class="content">
						<div class="row">
							<div class="col-lg-6" style="border-right: 1px solid #f0f0f0;">
								<!-- @if(Auth::check())
									
								<p class="text-primary"><i class="ti-angle-right"></i><a href="{{ URL::to( 'reports/assetactivity') }}"><?php echo trans('lang.assetactivity');?></a> </p>
								<hr>
									
								@endif	 -->
								@if(Auth::check())
									
								<p class="text-primary"><i class="ti-angle-right"></i><a href="{{ URL::to( 'reports/componentactivity') }}">Tool activity report</a> </p>
								<p class="text-primary"><i class="ti-angle-right"></i><a href="{{ URL::to( 'reports/outstationactivity') }}">Outstation Tool activity report</a> </p>
								<!-- <p class="text-primary"><i class="ti-angle-right"></i><a href="{{ URL::to( 'reports/bystatus') }}">Tool Status report</a> </p> -->
								<hr>
									
								@endif		

			
							</div>
						</div>
						
					</div>
				 </div>
			</div> 
		</div>

    </div>
</div>	


@endsection