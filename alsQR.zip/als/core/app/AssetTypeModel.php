<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetTypeModel extends Model
{
    //
}
