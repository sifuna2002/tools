<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Yajra\Datatables\Datatables;
use App\GoalModel;
use App\SettingModel;
use App\Http\Controllers\TraitSettings;
use DB;
use Auth;
use App;

class Reports extends Controller
{

	use TraitSettings;

	public function __construct() {
		$data = $this->getapplications();
		$lang = $data->language;
		App::setLocale($lang);
        $this->middleware('auth');
	}

	public function assetactivity() {
        return view( 'reports.assetactivitys' );
	}

	public function componentactivity() {
        return view( 'reports.componentactivity' );
	}

	public function maintenance() {
        return view( 'reports.maintenance' );
	}
    public function calibrated() {
        return view( 'reports.calibrated' );
	}

	public function bytype() {
        return view( 'reports.bytype' );
	}

	public function bysupplier() {
        return view( 'reports.bysupplier' );
	}

	public function bylocation() {
        return view( 'reports.bylocation' );
	}

	public function bystatus() {
        return view( 'reports.bystatus' );
	}
    // outstation
    public function outstation() {
        return view( 'reports.outstation' );
    }

	//show all report report view
	public function allreports(){
		return view('reports.reports');
	}


	/**
	 * get data asset from database
	 * @return object
	 */
    public function getassetactivityreport(Request $request){
        $start_date = $request->input('start_date');
        $end_date = $request->input('end_date');
        $query = DB::table('asset_history')
        ->select('asset_history.*', 'assets.fullname as asset', 'employees.fullname as employees', 'asset_type.name as type', 'location.name as location')
        ->leftJoin('assets', 'assets.id', '=', 'asset_history.assetid')
        ->leftJoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
        ->leftJoin('employees', 'employees.id', '=', 'asset_history.employeeid')
        ->leftJoin('location', 'location.id', '=', 'assets.locationid')
		->orderBy('asset_history.updated_at', 'desc')
		->orderBy('asset_history.created_at', 'desc');

		if (!empty($start_date) && !empty($end_date)) {
            $query->whereBetween('asset_history.created_at', [$start_date, $end_date]);
        }
    
        $data = $query->get();

        return Datatables::of($data)
        
        ->addColumn( 'status', function ( $accountsingle ) {
           

            if($accountsingle->status==2){
                    
                    $status = '<span class="badge badge-data text-white background-blue">'.trans('lang.checkin').'</span>';
                
            }else{
                    $status = '<span class="badge badge-data text-white background-yellow">'.trans('lang.checkout').'</span>';
            }

            return  $status;
           
        } )->rawColumns(['status'])
        ->make(true);		
    }

    /**
	 * get data  component from database
	 * @return object
	 */
    public function getcomponentactivityreport(Request $request){
        $start_date = $request->input('start_date');
        $end_date = $request->input('end_date');
        $query = DB::table('component_assets')
        ->select('component_assets.*', 'component_assets.serial as serial', 'component.name as component','assets.fullname as asset', 'asset_type.name as type', 'location.name as location')
        ->leftJoin('assets', 'assets.id', '=', 'component_assets.assetid')
        ->leftJoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
        ->leftJoin('location', 'location.id', '=', 'component_assets.aircraftid')
        ->leftJoin('component', 'component.id', '=', 'component_assets.componentid')
        ->offset(0)->limit(1000000)
		->orderBy('component_assets.updated_at', 'desc')
		->orderBy('component_assets.created_at', 'desc');

        if (!empty($start_date) && !empty($end_date)) {
            $query->whereBetween('component_assets.created_at', [$start_date, $end_date]);
        }

        $data = $query->get();

        return Datatables::of($data)
            ->addColumn('status', function ($accountsingle) {
                if ($accountsingle->status == 2) {
                    $status = '<span class="badge badge-data text-white background-blue">'.trans('lang.checkin').'</span>';
                } else {
                    $status = '<span class="badge badge-data text-white background-yellow">'.trans('lang.checkout').'</span>';
                }
                return $status;
            })
            ->addColumn('duration', function ($accountsingle) {
                // Assuming $accountsingle->date and $accountsingle->updated_at are in "Y-m-d H:i:s" format
                $startDate = strtotime($accountsingle->date); // Convert date to timestamp
                $updatedAt = strtotime($accountsingle->updated_at); // Convert updated_at to timestamp
                $createdAt = strtotime($accountsingle->created_at); // Convert created_at to timestamp
                
                // Check if status is 1 and the difference is zero
                if ($accountsingle->status == 1 && $startDate != $updatedAt) {
                    $currentDate = time(); // Get current timestamp
                    $todayStart = strtotime(date('Y-m-d')); // Get today's start timestamp
                    
                    // Calculate difference between date and today
                    $durationSeconds = abs($currentDate - $startDate); // Calculate duration in seconds
                    $secondsInDay = 60 * 60 * 24; // Seconds in a day
                    $days = floor($durationSeconds / $secondsInDay); // Calculate days

                    if ($updatedAt != $createdAt) {
                        return 'Checked-In';
                    }
                    
                    return ($days > 0) ? $days . ' days' : 'Less than a day'; // Return duration as string
                } elseif ($accountsingle->status == 1 && $startDate === $updatedAt) {
                    return 'Not Checked-In';
                } else {
                    return '';
                }
            })
            ->rawColumns(['status', 'duration'])
            ->make(true);
            
    }
    /**
	 * get data  component from database
	 * @return object
	 */
    public function getoutstationactivityreport(Request $request){
        $start_date = $request->input('start_date');
        $end_date = $request->input('end_date');
        $query = DB::table('outstation_assets')
        ->select('outstation_assets.*', 'outstation_assets.serial as serial', 'component.name as component','assets.fullname as asset', 'asset_type.name as type', 'location.name as location','supplier.name as supplier')
        ->leftJoin('assets', 'assets.id', '=', 'outstation_assets.assetid')
        ->leftJoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
        ->leftjoin('supplier', 'supplier.id', '=', 'outstation_assets.supplierid')
        ->leftJoin('location', 'location.id', '=', 'outstation_assets.aircraftid')
        ->leftJoin('component', 'component.id', '=', 'outstation_assets.componentid')
        ->offset(0)->limit(1000000)
		->orderBy('outstation_assets.updated_at', 'desc')
		->orderBy('outstation_assets.created_at', 'desc');

        if (!empty($start_date) && !empty($end_date)) {
            $query->whereBetween('outstation_assets.created_at', [$start_date, $end_date]);
        }

        $data = $query->get();

        return Datatables::of($data)
            ->addColumn('status', function ($accountsingle) {
                if ($accountsingle->status == 2) {
                    $status = '<span class="badge badge-data text-white background-blue">'.trans('lang.checkin').'</span>';
                } else {
                    $status = '<span class="badge badge-data text-white background-yellow">'.trans('lang.checkout').'</span>';
                }
                return $status;
            })
            ->addColumn('duration', function ($accountsingle) {
                // Assuming $accountsingle->date and $accountsingle->updated_at are in "Y-m-d H:i:s" format
                $startDate = strtotime($accountsingle->date); // Convert date to timestamp
                $updatedAt = strtotime($accountsingle->updated_at); // Convert updated_at to timestamp
                $createdAt = strtotime($accountsingle->created_at); // Convert created_at to timestamp
                
                // Check if status is 1 and the difference is zero
                if ($accountsingle->status == 1 && $startDate != $updatedAt) {
                    $currentDate = time(); // Get current timestamp
                    $todayStart = strtotime(date('Y-m-d')); // Get today's start timestamp
                    
                    // Calculate difference between date and today
                    $durationSeconds = abs($currentDate - $startDate); // Calculate duration in seconds
                    $secondsInDay = 60 * 60 * 24; // Seconds in a day
                    $days = floor($durationSeconds / $secondsInDay); // Calculate days

                    if ($updatedAt != $createdAt) {
                        return 'Checked-In';
                    }
                    
                    return ($days > 0) ? $days . ' days' : 'Less than a day'; // Return duration as string
                } elseif ($accountsingle->status == 1 && $startDate === $updatedAt) {
                    return 'Not Checked-In';
                } else {
                    return '';
                }
            })
            ->rawColumns(['status', 'duration'])
            ->make(true);
            
    }


    /**
	 * get asset data by type from database
	 * @return object
	 */
    public function getdatabytypereport(Request $request){
    	$data = DB::table('assets')
		->leftJoin('brand', 'assets.brandid', '=', 'brand.id')
		->leftJoin('supplier', 'assets.supplierid', '=', 'supplier.id')
		->leftjoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
		->leftJoin('location', 'assets.locationid', '=', 'location.id')
		->select(['assets.*', 'supplier.name as supplier', 'brand.name as brand','brand.id as brandid', 'asset_type.name as type' , 'location.name as location']);
		
       return Datatables::of($data)
        ->addColumn('pictures',function($single){
			return '<img src="'.url('/').'/upload/assets/'.$single->picture.'" style="width:90px"/>';
        })
        ->filter(function ($query) use ($request) {
				if ($request->has('assettype')) {

					$query->where('assets.typeid', 'like', "%{$request->get('assettype')}%");
				} 
			})
        ->rawColumns(['pictures'])
        ->make(true);		
    }


    /**
	 * get asset data by status from database
	 * @return object
	 */
    public function getdatabystatusreport(Request $request){
    	$data = DB::table('assets')
		->leftJoin('brand', 'assets.brandid', '=', 'brand.id')
		->leftJoin('supplier', 'assets.supplierid', '=', 'supplier.id')
		->leftjoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
		->leftJoin('location', 'assets.locationid', '=', 'location.id')
		->select(['assets.*', 'supplier.name as supplier', 'brand.name as brand','brand.id as brandid', 'asset_type.name as type' , 'location.name as location']);
		

       return Datatables::of($data)
        ->addColumn('pictures',function($single){
			return '<img src="'.url('/').'/upload/assets/'.$single->picture.'" style="width:90px"/>';
        })
        ->addColumn('status2', function($single){
        	//set status
            if($single->status=='1'){
                $status = trans('lang.readytodeploy');
            }
            if($single->status=='2'){
                $status = trans('lang.pending');
            }
            if($single->status=='3'){
                $status = trans('lang.archived');
            }
            if($single->status=='4'){
                $status = trans('lang.broken');
            }
            if($single->status=='5'){
                $status = trans('lang.lost');
            }
            if($single->status=='6'){
                $status = trans('lang.outofrepair');
            }

            return $status;
        })
        ->filter(function ($query) use ($request) {
				if ($request->has('statustype')) {

					$query->where('assets.status', 'like', "%{$request->get('statustype')}%");
				} 
			})
        ->rawColumns(['pictures','status2'])
        ->make(true);		
    }


    /**
	 * get asset data by supplier from database
	 * @return object
	 */
    public function getdatabysupplierreport(Request $request){
    	$data = DB::table('assets')
		->leftJoin('brand', 'assets.brandid', '=', 'brand.id')
		->leftJoin('supplier', 'assets.supplierid', '=', 'supplier.id')
		->leftjoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
		->leftJoin('location', 'assets.locationid', '=', 'location.id')
		->select(['assets.*', 'supplier.name as supplier', 'brand.name as brand','brand.id as brandid', 'asset_type.name as type' , 'location.name as location']);
		
       return Datatables::of($data)
        ->addColumn('pictures',function($single){
			return '<img src="'.url('/').'/upload/assets/'.$single->picture.'" style="width:90px"/>';
        })
        ->filter(function ($query) use ($request) {
				if ($request->has('supplierid')) {

					$query->where('assets.supplierid', 'like', "%{$request->get('supplierid')}%");
				} 
			})
        ->rawColumns(['pictures'])
        ->make(true);		
    }


    /**
	 * get asset data by location from database
	 * @return object
	 */
    public function getdatabylocationreport(Request $request){
    	$data = DB::table('assets')
		->leftJoin('brand', 'assets.brandid', '=', 'brand.id')
		->leftJoin('supplier', 'assets.supplierid', '=', 'supplier.id')
		->leftjoin('asset_type', 'assets.typeid', '=', 'asset_type.id')
		->leftJoin('location', 'assets.locationid', '=', 'location.id')
		->select(['assets.*', 'supplier.name as supplier', 'brand.name as brand','brand.id as brandid', 'asset_type.name as type' , 'location.name as location']);
		
       return Datatables::of($data)
        ->addColumn('pictures',function($single){
			return '<img src="'.url('/').'/upload/assets/'.$single->picture.'" style="width:90px"/>';
        })
        ->filter(function ($query) use ($request) {
				if ($request->has('locationid')) {

					$query->where('assets.locationid', 'like', "%{$request->get('locationid')}%");
				} 
			})
        ->rawColumns(['pictures'])
        ->make(true);		
    }




}
